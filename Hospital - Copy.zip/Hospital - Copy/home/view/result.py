from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from home.model.resiver import Receiver

@login_required
def result_view(request, receiver_id):
    try:
        receiver = Receiver.objects.get(id=receiver_id)
    except Receiver.DoesNotExist:
        return redirect('receiver_list')

    # Dummy matches for illustration. Replace this with real logic.
    matches = [
        {
            'id': 1,
            'hospital_name': request.user.hospitalprofile.hospital_name,
            'hla_percentage': 95,
            'blood_match_percentage': 80,
            'place': request.user.hospitalprofile.branch_name,
            'overall_match': 87,
        }
    ]

    return render(request, 'result.html', {
        'patient': receiver,
        'matches': matches,
    })
def approve_match(request, match_id):
    # For now, just redirect back. You can implement match logic here.
    print(f"Approved match ID: {match_id}")
    return redirect('receiver_list')
