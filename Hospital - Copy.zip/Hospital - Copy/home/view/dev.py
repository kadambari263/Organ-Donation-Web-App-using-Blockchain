from django.shortcuts import render

def dev_view(request):
    return render(request, 'other/dev.html')