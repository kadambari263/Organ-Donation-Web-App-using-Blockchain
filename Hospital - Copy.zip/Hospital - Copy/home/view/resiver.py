# views.py
from django.shortcuts import render, redirect,get_object_or_404
from home.form import ReceiverForm
import torch
from django.core.mail import send_mail
from home.model import Receiver, Donor
from home.utils import predict_match,LSTMModel,load_lstm_model  # Your custom matching logic (LSTM model, CDLSTM, etc.)

from django.contrib import messages

MODEL_PATH = 'home/models/lstm_model.pth'


# def receiver_register(request):
#     if request.method == 'POST':
#         receiver = Receiver(
#             name=request.POST.get('name'),
#             age=int(request.POST.get('age')),
#             blood_group=request.POST.get('blood_group'),
#             organ_needed=request.POST.get('organ_needed'),
#             mobile_number=request.POST.get('mobile_number'),
#             email=request.POST.get('email'),
#             hospital=request.POST.get('hospital', ''),
#             place=request.POST.get('place', ''),
#             aadhaar=request.POST.get('aadhaar'),
#             gender=request.POST.get('gender'),
#             hla_a=request.POST.get('hla_a'),
#             hla_b=request.POST.get('hla_b'),
#             hla_dr=request.POST.get('hla_dr'),
#         )
#         receiver.status = 'waiting'  # default
#         receiver.save()

#         model = load_lstm_model()
#         donors = Donor.objects.all()
#         for donor in donors:
#             if predict_match(receiver, donor, model):
#                 print("✅ Match found with donor:", donor)
#                 receiver.status = 'approved'
#                 receiver.matched_donor = donor 
#                 break

#         receiver.save()
#         print("✅ Final status saved as:", receiver.status)

#         return redirect('receiver_list')

#     return render(request, 'receiver/register.html')

def receiver_register(request):
    if request.method == 'POST':
        # 1. Create receiver
        receiver = Receiver(
            name=request.POST.get('name'),
            age=int(request.POST.get('age')),
            blood_group=request.POST.get('blood_group'),
            organ_needed=request.POST.get('organ_needed'),
            mobile_number=request.POST.get('mobile_number'),
            email=request.POST.get('email'),
            hospital=request.POST.get('hospital', ''),
            place=request.POST.get('place', ''),
            aadhaar=request.POST.get('aadhaar'),
            gender=request.POST.get('gender'),
            hla_a=request.POST.get('hla_a'),
            hla_b=request.POST.get('hla_b'),
            hla_dr=request.POST.get('hla_dr'),
            status='waiting'
        )
        receiver.save()

        # 2. Match using LSTM
        model = load_lstm_model()
        donors = Donor.objects.all()
        matched_donor = None

        for donor in donors:
            is_match, score = predict_match(receiver, donor, model)
            if is_match:
                receiver.status = 'approved'
                receiver.matched_donor = donor
                receiver.match_score = score  # Save raw score to DB
                matched_donor = donor
                break

        receiver.save()

        # 3. Send email to donor's added_by
        if matched_donor and matched_donor.added_by:
            send_request_email(matched_donor.added_by, receiver)

        return redirect('receiver_list')

    return render(request, 'receiver/register.html')



def receiver_list(request):
    patients = Receiver.objects.all()
    return render(request, 'receiver/receiver_list.html', {'patients': patients})

# views.py (continuation)
import csv
from django.http import HttpResponse

def download_receivers(request):
    receivers = Receiver.objects.all()

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="receivers.csv"'

    writer = csv.writer(response)
    writer.writerow(['Name', 'Age', 'Blood Group', 'Organ Needed', 'Status'])
    for receiver in receivers:
        writer.writerow([receiver.name, receiver.age, receiver.blood_group, receiver.organ_needed, receiver.status])

    return response



def receiver_edit(request, pk):
    receiver = get_object_or_404(Receiver, pk=pk)

    if request.method == 'POST':
        form = ReceiverForm(request.POST, instance=receiver)
        
        if form.is_valid():
            receiver = form.save()

            try:
                model = load_lstm_model()
                donors = Donor.objects.all()
                matched = False

                for donor in donors:
                    is_match, score = predict_match(receiver, donor, model)
                    if is_match:
                        receiver.status = "approved"
                        receiver.matched_donor = donor
                        receiver.match_score = score  # save score
                        matched = True
                        break

                if not matched:
                    receiver.status = "waiting"
                    receiver.matched_donor = None
                    receiver.match_score = 0.0  # reset score

                receiver.save()
                print(f"✅ Final status saved as: {receiver.status}")

                return redirect('receiver_list')

            except Exception as e:
                print(f"❌ Error during matching on edit for receiver {receiver.name}: {e}")
                form.add_error(None, "Error during matching. Please try again later.")

    else:
        form = ReceiverForm(instance=receiver)

    return render(request, 'receiver/edit.html', {'form': form, 'receiver': receiver})


# def receiver_result(request, pk):
#     receiver = get_object_or_404(Receiver, pk=pk)
#     donor = receiver.matched_donor

#     if not donor:
#         return render(request, 'receiver/result.html', {'receiver': receiver})

#     context = {
#         'receiver': receiver,  # <-- Add this line
#         'organ': donor.organ,
#         'blood_group': donor.blood_group,
#         'hospital': donor.hospital,
#         'age': donor.age,
#         'added_by': donor.added_by,
#     }
#     return render(request, 'receiver/result.html', context)

def receiver_result(request, pk):
    receiver = get_object_or_404(Receiver, pk=pk)
    donor = receiver.matched_donor

    if not donor:
        return render(request, 'receiver/result.html', {'receiver': receiver})

    match_score_percent = None
    if receiver.match_score is not None:
        raw_percent = round(abs(receiver.match_score) * 500, 4)
        match_score_percent = min(raw_percent, 80.0)  # Show score up to 80%

    context = {
        'receiver': receiver,
        'organ': donor.organ,
        'blood_group': donor.blood_group,
        'hospital': donor.hospital,
        'age': donor.age,
        'added_by': donor.added_by,
        'match_score_percent': match_score_percent,
    }
    return render(request, 'receiver/result.html', context)


def send_request_email_view(request):
    if request.method == 'POST':
        receiver_id = request.POST.get('receiver_id')
        receiver = get_object_or_404(Receiver, pk=receiver_id)
        donor = receiver.matched_donor

        if donor and donor.added_by:
            send_request_email(donor.added_by, receiver)
        messages.success(request, "Email sent successfully!")
        return redirect('receiver_result', pk=receiver.id)

    return redirect('receiver_list')
    

# This should be in email_utils.py or your views.py if local
from django.core.mail import send_mail

def send_request_email(user, receiver):
    donor = receiver.matched_donor

    subject = f"Organ Match Notification for Receiver: {receiver.name}"
    message = f"""
Dear {user.username},

A receiver has been matched with your donor.

Receiver Information:
- Name: {receiver.name}
- Organ Needed: {receiver.organ_needed}
- Blood Group: {receiver.blood_group}
- Hospital: {receiver.hospital}
- Age: {receiver.age}

Please take the necessary steps to proceed.

Regards,  
Organ Matching System
"""
    send_mail(subject, message, 'noreply@example.com', [user.email])
