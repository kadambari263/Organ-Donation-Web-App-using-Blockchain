from django.shortcuts import render, redirect
from home.form import DonorForm
from home.utils.blockchain import save_to_blockchain
from django.contrib.auth.decorators import login_required

@login_required(login_url='login') 
def donor_register(request):
    if request.method == 'POST':
        form = DonorForm(request.POST)
        if form.is_valid():
            donor = form.save(commit=False)  # Don't save yet
            donor.added_by = request.user  # Set current user as added_by
            donor = form.save()

            donor_data = {
                "name": donor.full_name,
                "age": donor.age,
                "organ": donor.organ,
                "blood_group": donor.blood_group,
                "mobile": donor.mobile_number,
                "aadhaar": donor.aadhaar,
                "hospital": donor.hospital,
                "place": donor.place,
                "hla_a": donor.hla_a,
                "hla_b": donor.hla_b,
                "hla_dr": donor.hla_dr,
            }

            block_hash = save_to_blockchain(donor_data)

            return render(request, 'doner/success.html', {
                'donor': donor,
                'block_hash': block_hash
            })
    else:
        form = DonorForm()
    
    return render(request, 'doner/register.html', {'form': form})
