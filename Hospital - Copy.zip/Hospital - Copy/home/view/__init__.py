from home.view import home
from home.view.auth import register_view,login_view,logout_view
from home.view.doner import donor_register
from home.view.resiver import download_receivers,receiver_list,receiver_register,receiver_edit,receiver_result,send_request_email,send_request_email_view
from home.view.profile import profile_view,edit_profile_view

