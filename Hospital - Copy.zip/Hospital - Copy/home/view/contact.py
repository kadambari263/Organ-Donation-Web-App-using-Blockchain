# home/view/contact.py
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.contrib import messages

def contact_page(request):
    return render(request, 'other/contact.html')

def contact_submit(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        full_message = f"Name: {name}\nEmail: {email}\n\n{message}"

        send_mail(subject, full_message, email, ['mediplus.soput@gmail.com'])
        messages.success(request, "Thank you for contacting us!")
        return redirect('contact_page')
