from django.contrib import admin
from home.model import Donor,Receiver,HospitalProfile

admin.site.register(Donor)
admin.site.register(Receiver)
admin.site.register(HospitalProfile)
# Register your models here.
